/**
 * Inventory Stock Viewer API for GitHub Pages + Google Sheets.
 * Deploy as a Web App after confirming the spreadsheet ID and tab name.
 */
const CONFIG = {
  SPREADSHEET_ID: '1f-Cao-yT033ulMObP4VmcIhQuSX5wQSrjyoLjj_vAa8',
  SHEET_NAME: 'Stock',
  DATA_START_ROW: 3
};

function doGet(e) {
  const params = (e && e.parameter) || {};
  if (params.api === '1') return jsonpResponse_(params.callback || '', getInventoryDataSafe_());
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('Inventory Stock Viewer')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

function getInventoryDataSafe_() {
  try { return getInventoryData(); }
  catch (err) { return { error: err && err.message ? err.message : String(err), rows: [], summary: { total: 0, available: 0, out: 0 }, updatedAt: new Date().toISOString() }; }
}

function jsonpResponse_(callback, data) {
  const safeCallback = /^[A-Za-z_$][0-9A-Za-z_$]*(\.[A-Za-z_$][0-9A-Za-z_$]*)*$/.test(callback) ? callback : '';
  const payload = JSON.stringify(data).replace(/</g, '\u003c').replace(/>/g, '\u003e').replace(/&/g, '\u0026');
  const output = safeCallback ? safeCallback + '(' + payload + ');' : 'window.INVENTORY_API_ERROR=' + payload + ';';
  return ContentService.createTextOutput(output).setMimeType(ContentService.MimeType.JAVASCRIPT);
}

function getInventoryData() {
  const ss = SpreadsheetApp.openById(String(CONFIG.SPREADSHEET_ID || '').trim());
  const sheet = ss.getSheetByName(CONFIG.SHEET_NAME);
  if (!sheet) throw new Error('Sheet tab "' + CONFIG.SHEET_NAME + '" was not found. Check CONFIG.SHEET_NAME.');
  const lastRow = sheet.getLastRow();
  if (lastRow < CONFIG.DATA_START_ROW) return { rows: [], summary: { total: 0, available: 0, out: 0 }, updatedAt: new Date().toISOString() };
  const values = sheet.getRange(CONFIG.DATA_START_ROW, 1, lastRow - CONFIG.DATA_START_ROW + 1, 9).getDisplayValues();
  const rows = [];
  values.forEach(function (r) {
    const name = String(r[1] || '').trim();
    if (!name) return;
    const stock = toNumber_(r[7]);
    rows.push({ sl: String(r[0] || rows.length + 1).trim(), name: name, unit: String(r[2] || '').trim(), issue: toNumber_(r[3]), mrr: toNumber_(r[4]), trnr: toNumber_(r[5]), trns: toNumber_(r[6]), stock: stock, location: String(r[8] || '').trim() });
  });
  return { rows: rows, summary: { total: rows.length, available: rows.filter(function (r) { return r.stock > 0; }).length, out: rows.filter(function (r) { return r.stock <= 0; }).length }, updatedAt: new Date().toISOString() };
}

function toNumber_(value) {
  if (typeof value === 'number') return isFinite(value) ? value : 0;
  const cleaned = String(value == null ? '' : value).replace(/,/g, '').trim();
  if (!cleaned) return 0;
  const n = Number(cleaned);
  return isFinite(n) ? n : 0;
}

function testInventoryConnection() {
  const data = getInventoryData();
  Logger.log('Inventory rows: ' + data.summary.total);
  return data.summary;
}
