# Inventory Stock Viewer — GitHub Pages edition

This package keeps the current dashboard design and reads live inventory rows from your Google Sheet through a Google Apps Script JSONP endpoint. GitHub Pages can host the HTML, but it cannot run `Code.gs` itself.

## Files
- `index.html` — GitHub Pages frontend (mobile responsive, search, filters, CSV export, frozen SL column, colored summary cards).
- `Code.gs` — Google Apps Script backend/API. It reads the `Stock` tab from your configured Google Sheet and avoids caching the large JSON response.
- `README.md` — these setup steps.

## Step 1 — Deploy the Apps Script API
1. Open your Google Sheet: `https://docs.google.com/spreadsheets/d/1f-Cao-yT033ulMObP4VmcIhQuSX5wQSrjyoLjj_vAa8/edit`
2. Choose **Extensions → Apps Script**.
3. Replace the contents of `Code.gs` with the `Code.gs` file from this package and Save.
4. Choose **Deploy → New deployment → Web app**.
5. Set **Execute as: Me**. For **Who has access**, choose the narrowest option that allows your intended GitHub dashboard users. If you choose **Anyone**, the API can expose inventory data to anyone who obtains the endpoint URL; do not use that setting for confidential stock data.
6. Deploy, authorize when prompted, and copy the Web App URL ending in `/exec`.
7. Test it by opening the URL with `?api=1&callback=testCallback` appended. A successful response should look like `testCallback({...});` and include `rows` and `summary`.

> If access is restricted to your organization or signed-in account, anonymous GitHub visitors may not be able to view the dashboard. Do not make the source spreadsheet public just to make the dashboard work. Choose an access policy that matches your data sensitivity.

## Step 2 — Set the API URL in the dashboard
1. Open `index.html` in a text editor.
2. Find this line near the start of the script:
   ```js
   const API_URL = 'https://script.google.com/macros/s/AKfycbzjr6Toj2SRFb3RiV8Ncb_bFNZWNNm-SIoXHXIKCig6WKXsWE3otZIkljbtVTyEb47R/exec';
   ```
3. The supplied deployment URL has already been inserted in the provided `index.html`. If you create a new deployment later, replace it with your new Web App URL, for example:
   ```js
   const API_URL = 'https://script.google.com/macros/s/YOUR_DEPLOYMENT_ID/exec';
   ```
4. Save the file.

## Step 3 — Upload to GitHub Pages
1. Create a GitHub repository (for example `inventory-stock-viewer`).
2. Upload `index.html` to the repository root. You may also upload `Code.gs` and `README.md` for backup/documentation; GitHub Pages will not execute `Code.gs`.
3. Open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**, branch `main`, folder `/ (root)`, then Save.
5. Open the Pages URL GitHub shows you. If the dashboard was already open, refresh it after changes.

## Notes
- The spreadsheet tab must be named `Stock`; the source columns are A:I and data starts on row 3.
- The frontend uses JSONP to call Apps Script without browser CORS fetch restrictions.
- Every person who can access the deployed API may be able to read the returned stock rows. Treat the API URL and deployment permissions accordingly.
- If you edit `Code.gs` later, deploy a **new version** in Apps Script for changes to take effect.
